"""
MiniNN - Minimal Neural Network
This code is a straigthforward and minimal implementation 
of a multi-layer neural network for training on MNIST dataset.
It is mainly intended for educational and prototyping purpuses.
"""
__author__ = "Gaetan Marceau Caron (gaetan.marceau-caron@inria.fr)"
__copyright__ = "Copyright (C) 2015 Gaetan Marceau Caron"
__license__ = "CeCILL 2.1"
__version__ = "1.0"

import numpy as np
from scipy.stats import bernoulli
import argparse

#############################
### Core functions
#############################

def initNetwork(nn_arch, act_func_name):
    """
        Initialize the neural network weights, activation function and return the number of parameters
  
        :param nn_arch: the number of units per hidden layer 
        :param act_func_name: the activation function name (sigmoid, tanh or relu)
        :type nn_arch: list of int
        :type act_func_name: str
        :return W: a list of weights for each hidden layer
        :return B: a list of bias for each hidden layer
        :return act_func: the activation function
        :return nb_params: the number of parameters 
        :rtype W: list of ndarray
        :rtype B: list of ndarray
        :rtype act_func: function
        :rtype n_params: number of parameters
    """

    W,B = [],[]
    sigma = 1.0
    act_func = globals()[act_func_name] # Cast the string to a function
    nb_params = 0
    
    for i in range(np.size(nn_arch)-1):
        #w = 0.01*np.ones((nn_arch[i+1],nn_arch[i]))
        w=np.random.normal(loc=0.0,scale=sigma/np.sqrt(nn_arch[i]),size=(nn_arch[i+1],nn_arch[i]))
        W.append(w)
        b = np.sum(w,1).reshape(-1,1)/-2.0
        #b= np.zeros((w.shape[0],1))
        B.append(b)
        nb_params += nn_arch[i+1] * nn_arch[i] + nn_arch[i+1]

    return W,B,act_func,nb_params


def dropout(p,h,hp=None):
    """
        Perform the dropout transformation to the activation values

        :param p: the probability of dropout
        :param h: the activation values
        :param hp: the derivatives w.r.t. the pre-activation values
        :type p: float
        :type h: ndarray
        :type hp: ndarray
        :return mask: the bernoulli mask
        :return h: the transformed activation values
        :return hp: the transformed derivatives w.r.t. z
        :rtype h: ndarray
        :rtype hp: ndarray
    """
    mask = np.random.binomial(1,p,size = h.shape)
    
    h = h * mask
    hp = hp * mask

	
    return mask,h,hp


def forward(act_func,W,B,X):
    """
        Perform the forward propagation

        :param act_func: the activation function 
        :param W: the weights
        :param B: the bias
        :param X: the input
        :param drop_func: the dropout function
        :type act_func: function
        :type W: list of ndarray
        :type B: list of ndarray
        :type X: ndarray
        :type drop_func: function
        :return H: a list of activation values
        :return Hp: a list of the derivatives w.r.t. the pre-activation of the activation values
        :rtype H: list of ndarray
        :rtype Hp: list of ndarray
    """
    #mask,h,hp = dropout(0.8,np.transpose(X),None)
    Y,Yp = [np.transpose(X)],[]
    #####################
    # TO BE COMPLETED
    #mask,h,hp = dropout(0.8,Y,Yp)
            
    for i in range(len(W)-1):
        if(i==0):
            a_l= W[i].dot(Y[i]) + B[i]
            F,Fp = act_func(a_l)
            mask,h,hp = dropout(0.8,F,Fp)
            Y.append(h)
            Yp.append(hp)
        else:
            a_l= W[i].dot(Y[i]) + B[i]
            F,Fp = act_func(a_l)
            mask,h,hp = dropout(0.5,F,Fp)
            Y.append(h)
            Yp.append(hp)
        
    Y.append(W[-1].dot(Y[-1])+B[-1])

    return Y, Yp

 

def backward(error,W,Yp):
    """
        Perform the backward propagation

        :param error: the gradient w.r.t. to the last layer 
        :param W: the weights
        :param Yp: the derivatives w.r.t. the pre-activation of the activation functions
        :type error: ndarray
        :type W: list of ndarray
        :type Yp: list of ndarray
        :return gradb: a list of gradient w.r.t. the pre-activation with this order [gradb_layer1, ..., error] 
        :rtype gradB: list of ndarray
    """
    #initialisation de gradB 

    gradB = [0]*(len(W)-1)+[error]
    #####################
    # TO BE COMPLETED
    for k in range(len(W)-1,0,-1):
        grad_layer= np.dot(W[k].T,gradB[k])
        gradB[k-1]= grad_layer * Yp[k-1]
        
    #assert(False),"backward must be completed before testing"
    #####################
    return gradB

def update(eta, batch_size, W, B, gradB, Y, regularizer, my_lambda):
    """
        Perform the update of the parameters

        :param eta: the step-size of the gradient descent 
        :param batch_size: number of examples in the batch (for normalizing)
        :param W: the weights
        :param B: the bias
        :param gradB: the gradient of the activations w.r.t. to the loss
        :param Y: the activation values
        :type eta: float
        :type batch_size: int
        :type W: list of ndarray
        :type B: list of ndarray
        :type gradB: list of ndarray
        :type Y: list of ndarray
        :return W: the weights updated 
        :return B: the bias updated 
        :rtype W: list of ndarray
        :rtype B: list of ndarray
    """
    #####################
   
    # TO BE COMPLETED
    for k in range(len(W)):
        grad_w = np.dot(gradB[k],Y[k].T)/batch_size
        grad_b = np.sum(gradB[k], axis=1)/batch_size
        W[k] = updateParams(W[k],grad_w, eta,regularizer, my_lambda)
        B[k] = updateParams(B[k],grad_b.reshape(-1,1), eta,regularizer,my_lambda)
    grad_b.shape
    #####################
    # Use updateParams(W[k],grad_w, eta) and updateParams(B[k],grad_b, eta)
    # grad_b should be a vector: object.reshape(-1,1) can be useful
    
    #assert(False),"update must be completed before testing"
    return W,B

#############################
#############################

#############################
### Activation functions
#############################
def sigmoid(z):
    """
        Perform the sigmoid transformation to the pre-activation values

        :param z: the pre-activation values
        :param grad_flag: flag for computing the derivatives w.r.t. z
        :type z: ndarray
        :type grad_flag: boolean
        :return y: the activation values
        :return yp: the derivatives w.r.t. z
        :rtype y: ndarray
        :rtype yp: ndarray
    """
    #####################
    # TO BE COMPLETED
    #####################
    # compute the sigmoid y and its derivative yp
    #if (z<-30.0):
        #y = -30.0
    #elif (z>30.0):
        #y = 30.0
    y= 1/(1+np.exp(-z))
    yp= y*(1-y)
        
    #assert(False),"sigmoid must be completed before testing"
    return y,yp

#### fonction d'activation RELU ####
def ReLU(z):
    y = np.maximum(0,z)
    yp = 1. * (z > 0)
    return y,yp 

def softmax(z):
    """
        Perform the softmax transformation to the pre-activation values

        :param z: the pre-activation values
        :type z: ndarray
        :return: the activation values
        :rtype: ndarray
    """
    return np.exp(z-np.max(z,0))/np.sum(np.exp(z-np.max(z,0)),0.)
#############################


def updateParams(theta, dtheta, eta, regularizer=None, my_lambda=0.):
    """
        Perform the update of the parameters with the 
        possibility to do L1 or L2 regularization 

        :param theta: the network parameters
        :param dtheta: the updates of the parameters
        :param eta: the step-size of the gradient descent 
        :param regularizer: the name of the regularizer
        :param my_lambda: the value of the regularizer
        :type theta: ndarray
        :type dtheta: ndarray
        :type eta: float
        :type regularizer: str
        :type my_lambda: float
        :return: the parameters updated 
        :rtype: ndarray
    """

    if regularizer==None:
        
        return theta - eta * dtheta
##### regularization        
    #if regularizer == 'L1':
        
        #return  theta - eta * dtheta - (eta * my_lambda * np.sign(theta))
    
    #if regularizer == 'L2':
        
        #return theta - eta * dtheta - (2 * eta * my_lambda * theta)
    if regularizer == 'L1':
        lambdas = np.where(theta>0,my_lambda,-my_lambda)
        return theta - eta * (dtheta+lambdas)
    elif regularizer == 'L2':
        lambdas = my_lambda*(theta/np.linalg.norm(theta))
        return theta - eta * (dtheta+lambdas)
    else:
        return theta - eta * dtheta
#############################

#############################
## Auxiliary functions 
#############################
def getMiniBatch(i, batch_size, train_set, one_hot):
    """
        Return a minibatch from the training set and the associated labels

        :param i: the identifier of the minibatch
        :param batch_size: the number of training examples
        :param train_set: the training set
        :param one_hot: the one-hot representation of the labels
        :type i: int
        :type batch_size: int
        :type train_set: ndarray
        :type ont_hot: ndarray
        :return: the minibatch of examples
        :return: the minibatch of labels
        :return: the number of examples in the minibatch
        :rtype: ndarray
        :rtype: ndarray
        :rtype: int
    """
    
    ### Mini-batch creation
    n_training = np.size(train_set[1])
    idx_begin = i * batch_size
    idx_end = min((i+1) * batch_size, n_training)
    mini_batch_size = idx_end - idx_begin

    batch = train_set[0][idx_begin:idx_end]
    one_hot_batch = one_hot[:,idx_begin:idx_end]

    return np.asfortranarray(batch), one_hot_batch, mini_batch_size

def computeLoss(W, B, batch, labels, act_func):
    """
        Compute the loss value of the current network on the full batch

        :param W: the weights
        :param B: the bias
        :param batch: the weights
        :param labels: the bias
        :param act_func: the weights
        :type W: ndarray
        :type B: ndarray
        :type batch: ndarray
        :type act_func: function
        :return loss: the negative log-likelihood
        :return accuracy: the ratio of examples that are well-classified
        :rtype: float
        :rtype: float
    """
    
    ### Forward propagation
    h = np.transpose(batch)
    for k in range(len(W)-1):
        h,hp = act_func(W[k].dot(h)+B[k])
    z = W[-1].dot(h)+B[-1]

    ### Compute the softmax
    out = softmax(z)
    pred = np.argmax(out,axis=0)
    fy = out[labels,np.arange(np.size(labels))]
    try:
        loss = np.sum(-1. * np.log(fy))/np.size(labels)
    except Exception:
        fy[fy<1e-4] = fy[fy<1e-4] + 1e-6
        loss = np.sum(-1. * np.log(fy))/np.size(labels)
    accuracy = np.sum(np.equal(pred,labels))/float(np.size(labels))        
    
    return loss,accuracy

def parseArgs():
    # Retrieve the arguments
    parser = argparse.ArgumentParser(description='MiniNN -- Minimalist code for Neural Network Learning')
    parser.add_argument('--arch', help='Architecture of the hidden layers', default=[512,256,128,64,32,16], nargs='+', type=int)
    parser.add_argument('--act_func', help='Activation function name', default="sigmoid", type=str)
    parser.add_argument('--batch_size', help='Minibatch size', default=500, type=int)
    parser.add_argument('--eta', help='Step-size for the optimization algorithm', default=1.0, type=float)
    parser.add_argument('--n_epoch', help='Number of epochs', default=100, type=int)
    parser.add_argument('--regularization', help='regularization', default='L2', type=str)
    parser.add_argument('--lambda', help='lambda', default=0.1, type=float)

    args = parser.parse_args()
    return args

def parseArgs_ipython(**kwarg):
    """ Adaptation de parseArgs() pour IPython """
    class Arguments():
        
        def __init__(self, arch = [100], act_func = "sigmoid", batch_size = 500, eta = .01, n_epoch = 100, regularization = "L2",dropout=True, my_lambda = 0.1):
    
            self.arch = arch
            self.act_func = act_func
            self.batch_size = batch_size
            self.eta = eta
            self.n_epoch = n_epoch
            self.regularization = regularization
            self.dropout = dropout
            self.my_lambda = my_lambda

    return Arguments(**kwarg)



#############################

#############################
## Printing function
#############################
def printDescription(algo_name, eta, nn_arch, act_func_name, minibatch_size, nb_param, regularization,dropout,my_lambda):
    print("Description of the experiment")
    print("----------")
    print("Learning algorithm: " + algo_name)
    print("Initial step-size: " + str(eta))
    print("Network Architecture: " + str(nn_arch))
    print("Number of parameters: " + str(nb_param))
    print("Minibatch size: " + str(minibatch_size))
    print("Activation: " +  act_func_name)
    print("Regularization: " +  str(regularization))
    print("dropout: " +  str(dropout))
    print("lambda: " +  str(my_lambda))
    print("----------")
#############################

